#include "Sub.h"
Sub::Sub(Expression a, Expression b)
{

}
Sub::~Sub()
{

}
