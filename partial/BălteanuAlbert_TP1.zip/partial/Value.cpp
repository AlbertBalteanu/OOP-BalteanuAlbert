#include "Value.h"
Value::Value(int n)
{

}
Value::~Value()
{

}