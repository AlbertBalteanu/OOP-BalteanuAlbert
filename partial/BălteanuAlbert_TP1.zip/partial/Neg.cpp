#include "Neg.h"
Neg::Neg(Expression a)
{

}
Neg::~Neg()
{

}
